from .lattice import Lattice
from .simclass import Ferro2DSim